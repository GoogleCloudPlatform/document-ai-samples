#!/bin/bash

# Prompt user for project and function names
PROJECT_NAME="rand-automl-project"
FUNCTION_NAME="daira-test-function_github_zaid_5"
LOCATION="us"
BUCKET_NAME="daira_test_zaid_5"
SERVICE_ACCOUNT_NAME="diara-shell-test"
SCHEDULER_NAME="daira-shell-scheduler-zaid-5"
